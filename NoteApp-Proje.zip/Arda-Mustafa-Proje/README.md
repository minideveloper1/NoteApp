# NOTEAPP

NOTEAPP, kullanıcıların not almasını sağlayan basit ve işlevsel bir web uygulamasıdır. Notlar klavyeden **Ctrl + Enter** tuş kombinasyonu ile kaydedilir ve her not kutusunun sağ üst köşesindeki çarpı (X) butonuyla silinebilir. Silinen notlar tamamen kaybolmaz — **Geri Alınabilir Notlar** bölmesi üzerinden geri yüklenebilir.

## Özellikler

- 📝 Not ekleme (Ctrl + Enter)
- ❌ Not silme (X butonu ile)
- ♻️ Silinen notları geri alma
- 🔍 Not arama (isteğe bağlı filtreleme)
- 📦 Veriler MySQL veritabanında saklanır

## Kullanılan Teknolojiler

- ASP.NET Core 9.0 (Blazor WebAssembly)
- MySQL
- .NET 9.0 SDK

## 📦 Kullanılan NuGet Paketleri

| Paket Adı                          | Açıklama                                             |
|-----------------------------------|------------------------------------------------------|
| `Dapper`                          | Hızlı ve hafif veri erişimi için mikro ORM           |
| `Microsoft.EntityFrameworkCore`   | .NET için güçlü ORM (veri modeli ve sorgu altyapısı) |
| `Microsoft.EntityFrameworkCore.Design` | Tasarım zamanı desteği sağlar (migration vs.)  |
| `Microsoft.EntityFrameworkCore.Tools`  | EF Core CLI komutları için araçlar                  |
| `MySqlConnector`                  | MySQL veritabanı ile bağlantı kurmak için            |

## 📁 Proje Yapısı

```
NOTEAPP/
├── Pages/                  # Blazor bileşenleri (.razor dosyaları)
├── Data/                   # Veri modelleri ve servisler
├── wwwroot/                # Statik dosyalar (CSS, JS)
├── appsettings.json        # Yapılandırma dosyası
├── Program.cs              # Uygulama başlangıç noktası
└── README.md               # Bu dosya
```

## 🚀 Kurulum

1. Bu projeyi klonlayın:

   ```bash
   git clone https://github.com/kullaniciadi/NOTEAPP.git
   cd NoteApp
   ```

2. MySQL veritabanını oluşturun:

   ```sql
   CREATE DATABASE IF NOT EXISTS notesdb
     CHARACTER SET utf8mb4
     COLLATE utf8mb4_0900_ai_ci;

   USE notesdb;

   CREATE TABLE IF NOT EXISTS notes (
       NoteId INT NOT NULL AUTO_INCREMENT,
       Title VARCHAR(255) NOT NULL,
       Content TEXT,
       CreatedAt DATETIME,
       IsDeleted TINYINT(1) DEFAULT 0,
       PRIMARY KEY (NoteId)
   );
   ```

3. `appsettings.json` dosyasındaki MySQL bağlantı bilgilerini kendi bilgilerinizle güncelleyin.

4. Uygulamayı başlatın:

   ```bash
   dotnet run
   ```



## 📝 Lisans

Bu proje MIT Lisansı ile lisanslanmıştır. Ayrıntılar için `LICENSE` dosyasına bakabilirsiniz.
