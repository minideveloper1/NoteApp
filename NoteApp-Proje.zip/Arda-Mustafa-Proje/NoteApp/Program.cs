using MySqlConnector;
using NoteApp.Data;
using NoteApp.Models;
using NoteApp.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// MySQL connection configuration
var mysqlConnection = new MySqlConnection(
    "Server=localhost;" +
    "Port=3306;" +
    "Database=notesdb;" +
    "User=root;" +
    "Password=1234;" +
    "CharSet=utf8mb4;");

// Register MySQL Connection
builder.Services.AddSingleton(mysqlConnection);
builder.Services.AddTransient<AppDbContext>();
builder.Services.AddScoped<INoteService, NoteService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Notes}/{action=Index}/{id?}");

app.Run();