using Microsoft.EntityFrameworkCore;
using NoteApp.Data;
using NoteApp.Models;

namespace NoteApp.Services
{
    public class NoteService : INoteService
    {
        private readonly AppDbContext _context;

        public NoteService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Note>> GetAllNotesAsync()
        {
            try
            {
                await _context.OpenConnection();
                var notes = await _context.GetAllNotes();
                return notes.ToList();
            }
            finally
            {
                await _context.CloseConnection();
            }
        }

        public async Task<Note?> GetNoteByIdAsync(int id)
        {
            try
            {
                await _context.OpenConnection();
                return await _context.GetNoteById(id);
            }
            finally
            {
                await _context.CloseConnection();
            }
        }

        public async Task<List<Note>> SearchNotesAsync(string searchTerm)
        {
            try
            {
                await _context.OpenConnection();
                if (string.IsNullOrEmpty(searchTerm))
                    return await GetAllNotesAsync();

                var notes = await _context.SearchNotes(searchTerm);
                return notes.ToList();
            }
            finally
            {
                await _context.CloseConnection();
            }
        }

        public async Task<Note> CreateNoteAsync(Note note)
        {
            try
            {
                await _context.OpenConnection();
                note.CreatedAt = DateTime.Now;
                return await _context.CreateNote(note);
            }
            finally
            {
                await _context.CloseConnection();
            }
        }

        public async Task<Note> UpdateNoteAsync(Note note)
        {
            try
            {
                await _context.OpenConnection();
                return await _context.UpdateNote(note);
            }
            finally
            {
                await _context.CloseConnection();
            }
        }

        public async Task DeleteNoteAsync(int id)
        {
            try
            {
                await _context.OpenConnection();
                await _context.DeleteNote(id);
            }
            finally
            {
                await _context.CloseConnection();
            }
        }
    }
}