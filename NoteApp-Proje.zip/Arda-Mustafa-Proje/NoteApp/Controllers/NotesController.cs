using Microsoft.AspNetCore.Mvc;
using NoteApp.Models;
using NoteApp.Services;
using System.Collections.Generic;
using System.Linq;
using NoteApp.Data;
using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace NoteApp.Controllers
{
    public class NotesController : Controller
    {
        private readonly INoteService _noteService;
        private readonly AppDbContext _context;

        public NotesController(INoteService noteService, AppDbContext context)
        {
            _noteService = noteService;
            _context = context;
        }

        public async Task<IActionResult> Index(string searchTerm = "")
        {
            ViewBag.SearchTerm = searchTerm;
            IEnumerable<Note> notesQuery = await _context.GetAllNotes();
            notesQuery = notesQuery.Where(n => n.IsDeleted == false);

            if (!string.IsNullOrEmpty(searchTerm))
            {
                notesQuery = notesQuery.Where(n => 
                    n.Title.Contains(searchTerm) || n.Content.Contains(searchTerm));
            }

            var notes = notesQuery.OrderByDescending(n => n.CreatedAt).ToList<Note>();
            return View(notes);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Note note)
        {
            if (ModelState.IsValid)
            {
                await _noteService.CreateNoteAsync(note);
                return RedirectToAction(nameof(Index));
            }
            return View(note);
        }

        public async Task<IActionResult> Edit(int id)
        {
            var note = await _noteService.GetNoteByIdAsync(id);
            if (note == null)
            {
                return NotFound();
            }
            return View(note);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Note note)
        {
            if (id != note.NoteId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                await _noteService.UpdateNoteAsync(note);
                return RedirectToAction(nameof(Index));
            }
            return View(note);
        }

        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            await _context.DeleteNote(id);
            await _context.SaveChangesAsync();

            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> QuickSave([FromBody] Note note)
        {
            if (ModelState.IsValid)
            {
                if (note.NoteId == 0)
                {
                    
                    note.CreatedAt = DateTime.Now;
                    note.IsDeleted = false;
                    await _context.CreateNote(note);
                }
                else
                {
                    
                    var existingNote = await _context.GetNoteById(note.NoteId);
                    if (existingNote == null)
                    {
                        return NotFound();
                    }

                    existingNote.Title = note.Title;
                    existingNote.Content = note.Content;
                    existingNote.UpdatedAt = DateTime.Now;
                }

                await _context.SaveChangesAsync();
                return Json(new { 
                    success = true, 
                    id = note.NoteId, 
                    createdAt = note.CreatedAt 
                });
            }
            
            return Json(new { success = false });
        }

        public async Task<IActionResult> SaveNote(int id, string content)
        {
            await _context.OpenConnection();
            
            try
            {
                if (id == 0)
                {
                    // Yeni not oluşturmasini saglar
                    var note = new Note
                    {
                        Title = "Yeni Not",  
                        Content = content,
                        CreatedAt = DateTime.Now,
                        IsDeleted = false
                    };
                    
                    var createdNote = await _context.CreateNote(note);
                    return Json(new { success = true, noteId = createdNote.NoteId });
                }
                else
                {
                    // Var olan notu güncellemek cin yazildi 
                    var note = await _context.GetNoteById(id);
                    if (note != null)
                    {
                        note.Content = content;
                        await _context.UpdateNote(note);
                        return Json(new { success = true, noteId = note.NoteId });
                    }
                }
                
                return Json(new { success = false });
            }
            finally
            {
                await _context.CloseConnection();
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteNote(int id)
        {
            await _context.OpenConnection();
            
            try
            {
                var success = await _context.DeleteNote(id);
                return Json(new { success });
            }
            finally
            {
                await _context.CloseConnection();
            }
        }

        [HttpPost]
        public async Task<IActionResult> RestoreNote(int id)
        {
            var note = await _context.GetNoteById(id);
            if (note == null)
            {
                return NotFound();
            }

            note.IsDeleted = false;
            await _context.UpdateNote(note);
            await _context.SaveChangesAsync();

            return Json(new { success = true });
        }

        [HttpGet]
        public async Task<IActionResult> GetDeletedNotes()
        {
            var Notes = await _context.GetAllNotes();
            
            return Json(Notes.Where(n => n.IsDeleted == true).ToList());
        }

        [HttpGet]
        public async Task<IActionResult> GetNoteById(int id)
        {
            var note = await _context.GetNoteById(id);
            if (note == null)
            {
                return NotFound();
            }

            return Json(note);
        }
    }
}