using MySqlConnector;
using NoteApp.Models;
using Dapper;

namespace NoteApp.Data
{
    public class AppDbContext
    {
        private readonly MySqlConnection _connection;
        private const string TableName = "Notes";
        private bool _isInit = false;

        public AppDbContext(MySqlConnection connection)
        {
            _connection = connection;
        }

        private async Task EnsureInitialized()
        {
            if (!_isInit)
            {
                await InitializeDatabase();
                _isInit = true;
            }
        }

        public async Task OpenConnection()
        {
            if (_connection.State != System.Data.ConnectionState.Open)
            {
                await _connection.OpenAsync();
                await EnsureInitialized();
            }
        }

        public async Task CloseConnection()
        {
            if (_connection.State != System.Data.ConnectionState.Closed)
            {
                await _connection.CloseAsync();
            }
        }

        private async Task InitializeDatabase()
        {
            try {
                var tableExists = await _connection.QueryFirstOrDefaultAsync<int>(
                    "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'Notes'",
                    new { TableName });

                if (tableExists == 0)
                {
                    await _connection.ExecuteAsync($@"
                        CREATE TABLE {TableName} (
                            NoteId INT PRIMARY KEY AUTO_INCREMENT,
                            Title VARCHAR(255) NOT NULL,
                            Content TEXT NOT NULL,
                            CreatedAt DATETIME NOT NULL,
                            IsDeleted BOOLEAN NOT NULL DEFAULT FALSE
                        )");

                    // Seed data
                    var notes = new[]
                    {
                        new { Title = "Örnek Not 1", Content = "Bu bir örnek nottur." },
                        new { Title = "Toplantı Notları", Content = "Pazartesi günü saat 10:00'da toplantı var." },
                        new { Title = "Alışveriş Listesi", Content = "Süt, ekmek, peynir" }
                    };

                    foreach (var note in notes)
                    {
                        await _connection.ExecuteAsync(
                            $"INSERT INTO {TableName} (Title, Content, CreatedAt) VALUES (@Title, @Content, @CreatedAt)",
                            new { note.Title, note.Content, CreatedAt = DateTime.Now });
                    }
                }
            }
            catch (Exception ex)
            {
                //Console.WriteLine($"Database initialization failed: {ex.Message}");
                throw new Exception("Database initialization failed", ex);
            }
        }

        public async Task<IEnumerable<Note>> GetAllNotes()
        {
            return await _connection.QueryAsync<Note>(
                $"SELECT * FROM {TableName}");
        }

        public async Task<Note?> GetNoteById(int id)
        {
            return await _connection.QueryFirstOrDefaultAsync<Note>(
                $"SELECT * FROM {TableName} WHERE NoteId = @Id",
                new { Id = id });
        }

        public async Task<IEnumerable<Note>> SearchNotes(string searchTerm)
        {
            return await _connection.QueryAsync<Note>(
                $"SELECT * FROM {TableName} WHERE IsDeleted = 0 AND (Title LIKE @Search OR Content LIKE @Search) ORDER BY CreatedAt DESC",
                new { Search = $"%{searchTerm}%" });
        }

        public async Task<Note> CreateNote(Note note)
        {
            var id = await _connection.QuerySingleAsync<int>(
                $"INSERT INTO {TableName} (Title, Content, CreatedAt, IsDeleted) VALUES (@Title, @Content, @CreatedAt, @IsDeleted); SELECT LAST_INSERT_ID();",
                note);
            note.NoteId = id;
            return note;
        }

        public async Task<Note> UpdateNote(Note note)
        {
            await _connection.ExecuteAsync(
                $"UPDATE {TableName} SET Title = @Title, Content = @Content, IsDeleted = @IsDeleted WHERE NoteId = @NoteId",
                note);
            return note;
        }

        public async Task<bool> DeleteNote(int id)
        {
            var result = await _connection.ExecuteAsync(
                $"UPDATE {TableName} SET IsDeleted = 1 WHERE NoteId = @Id",
                new { Id = id });
            return result > 0;
        }

        public async Task<bool> HardDeleteNote(int id)
        {
            var result = await _connection.ExecuteAsync(
                $"DELETE FROM {TableName} WHERE NoteId = @Id",
                new { Id = id });
            return result > 0;
        }

        public async Task SaveChangesAsync()
        {
            
            await Task.CompletedTask;
        }
    }
}